<?php
include('config.php');

if (isset($_POST['submit'])) {

    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    // print_r($phone); 
    $course = $_POST['course'];

    $sql = "INSERT INTO registration (name, email, phone, course) 
            VALUES ('$name', '$email', '$phone', '$course')";
        // print_r($sql); 
    if ($conn->query($sql) === TRUE) {
        // echo "New record add successfully";
        header("Location: list.php");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>

<?php
session_start(); 

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
    include('config.php'); 
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $course = $_POST['course'];

    $sql = "INSERT INTO registration (name, email, phone, course) 
    VALUES ('$name', '$email', '$phone', '$course')";

    if (mysqli_query($conn, $sql)) {
    
        $_SESSION['success'] = "Student added successfully!";
        header("Location: list.php"); 
        exit();
    } else {
        $_SESSION['error'] = "Error adding student: " . mysqli_error($conn);
    }

    mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Add Student</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f0f0f0;
      padding: 50px;
    }
    .form-container {
      background-color: #fff;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
      width: 400px;
      margin: auto;
    }
    h2 {
      text-align: center;
      color: #333;
    }
    label {
      font-weight: bold;
      display: block;
      margin: 10px 0 5px;
    }
    input[type="text"], input[type="email"], input[type="tel"], select {
      width: 100%;
      padding: 10px;
      margin-bottom: 15px;
      border: 1px solid #ccc;
      border-radius: 5px;
    }
    button {
      width: 100%;
      padding: 12px;
      background-color: #4CAF50;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }
    button:hover {
      background-color: #45a049;
    }
    .success {
        color: green;
        font-weight: bold;
    }
    .error {
        color: red;
        font-weight: bold;
    }
  </style>
</head>
<body>

  <div class="form-container">
    <h2>Add New Student</h2>

    <?php if (isset($_SESSION['success'])): ?>
        <div class="success">
            <?php echo $_SESSION['success']; ?>
        </div>
        <?php unset($_SESSION['success']); ?> 
    <?php endif; ?>

    <?php if (isset($_SESSION['error'])): ?>
        <div class="error">
            <?php echo $_SESSION['error']; ?>
        </div>
        <?php unset($_SESSION['error']); ?> 
    <?php endif; ?>

    <form action="" method="POST">
      <label for="name">Name:</label>
      <input type="text" id="name" name="name" required>

      <label for="email">Email:</label>
      <input type="email" id="email" name="email" required>

      <label for="phone">Phone:</label>
      <input type="tel" id="phone" name="phone" required>

      <label for="course">Course:</label>
      <select id="course" name="course" required>
        <option value="">-- Select Course --</option>
        <option value="BCA">BCA</option>
        <option value="MCA">MCA</option>
        <option value="B.Tech">B.Tech</option>
        <option value="MBA">MBA</option>
      </select>

      <button type="submit" name="submit">Submit</button>
    </form>
  </div>

</body>
</html>
